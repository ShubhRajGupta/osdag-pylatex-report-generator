# Beam Analysis Report Generator

A Python-based tool for generating professional PDF engineering reports for simply supported beam analysis using LaTeX, TikZ, and pgfplots.

##  Overview

This project automates the generation of structural analysis reports for simply supported beams. It reads force data from an Excel file and produces a professional PDF report with:

- Vector-based Shear Force Diagrams (SFD)
- Vector-based Bending Moment Diagrams (BMD)
- Properly formatted data tables
- Professional title page and table of contents

##  Quick Start

```powershell
# Navigate to project directory
cd X:\Participations\FOSSEE\Latex2

# Run the generator
python code.py
```

##  Project Structure

```
Latex2/
├── code.py                      # Main Python script
├── Force Table.xlsx             # Input data (x, Shear Force, Bending Moment)
├── simply_supported_beam.png    # Beam diagram for report
├── Beam_Analysis_Report.pdf     # Generated output
├── Beam_Analysis_Report.tex     # Generated LaTeX source
├── README.md                    # This file
├── DOCUMENTATION.md             # Detailed documentation
└── TECHNICAL_DISCUSSION.md      # Technical journey & implementation details
```

##  Dependencies

### Python Packages
- `pandas` - Excel file reading and data manipulation
- `openpyxl` - Excel file engine (required by pandas)

### LaTeX Distribution
- **MiKTeX** or **TeX Live** with the following packages:
  - `tikz`, `pgfplots` - Vector graphics
  - `geometry`, `fancyhdr` - Page layout
  - `hyperref` - Clickable links
  - `booktabs`, `colortbl` - Table formatting
  - `graphicx` - Image embedding

##  Input Data Format

The Excel file (`Force Table.xlsx`) should have the following structure:

| x | Shear force | Bending Moment |
|---|-------------|----------------|
| 0.0 | 45 | 0.00 |
| 1.5 | 36 | 60.75 |
| ... | ... | ... |

##  Output Features

1. **Title Page**: Professional cover with project information
2. **Table of Contents**: Auto-generated, clickable navigation
3. **Introduction**: Beam theory with embedded diagram
4. **Data Table**: LaTeX tabular (selectable text, colored headers)
5. **SFD**: Bar chart with positive (blue) and negative (red) forces
6. **BMD**: Bar chart with moment values (green)
7. **Conclusion**: Summary of critical values

###  License

Thi3s project was created for the FOSSEE initiative.

### Author

Generated for FOSSEE Project - February 2026
